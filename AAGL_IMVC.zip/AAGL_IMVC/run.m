clear;
clc;
addpath('./measure');
resultdir = 'Results/';
if (~exist('Results', 'file'))
    mkdir('Results');
    addpath(genpath('Results/'));
end

datadir='datasets/';
dataname = {'bbcsport-4view'};

%bbcsport-4view alpha=0.5;numanchor=2*k;
del=0.1;

for idata=1:length(dataname)
    load([char(datadir),char(dataname(idata))]);

    for perMising=1:length(del)
        tic;
        datafolds=[char(datadir),char(dataname(idata)),'_Per',num2str(del(perMising))];
        load(datafolds);
        t1=toc;
        Tlable=Y;
        numclass= length(unique(Tlable));
        k= numclass;
        alpha=0.5;
        numanchor=2*k;
        N=size(X{1},2);
        numview=length(X);
        R=zeros(10,8);
        for f=1:10
            tic;
            fold=folds{f};
            X1=cell(length(X),1);
            for iv=1:length(X)
                index{iv} = find(fold(:,iv) == 1);
                missingindex{iv} = find(fold(:,iv) == 0);
                X1{iv} = NormalizeFea(X{iv},0);
                ind_0 = find(fold(:,iv) == 0);
                X1{iv}(:,ind_0) = 0;
            end
            disp([char(dataname(idata)),'_per',num2str(del(perMising)), ' alpha=', num2str(alpha), ' numanchor=', num2str(numanchor)]);

            [F,U,Z,obj,iter]=AAGL_Train(X1,Tlable,numanchor,k,index,missingindex,alpha);


            MAXiter = 1000;
            REPlic = 20;
            res=zeros(REPlic,8);

            for rep = 1 : 20
                pY = kmeans(F, numclass, 'maxiter', MAXiter, 'replicates', REPlic, 'EmptyAction', 'singleton');
                res(rep, : ) = Clustering8Measure(Tlable, pY);
                %result = [Fscore Precision Recall nmi AR Entropy ACC Purity];
            end
            t2=toc;
            time=t1+t2;
            disp(['runtime:', num2str(time)]);
            tmpResBest=mean(res);
            R(f,:)=tmpResBest*100;
        end
        ResBest=mean(R);
        ResStd=std(R);
        mean_acc=mean(ResBest(7));
        std_acc = std(ResStd(7));
        mean_nmi=mean(ResBest(4));
        std_nmi = std(ResStd(4));
        mean_pur=mean(ResBest(8));
        std_pur = std(ResStd(8));
        disp(['acc=',num2str(mean_acc),'----nmi=',num2str(mean_nmi),'----pur=',num2str(mean_pur)]);
        save([resultdir, char(dataname(idata)),'_per',num2str(del(perMising)),'_result.mat'], "ResBest","ResStd");
    end
end

