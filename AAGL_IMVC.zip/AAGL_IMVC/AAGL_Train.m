function [UU,U,Z,obj,iter]=AAGL_Train(X,Tlable,numanchor,k,index,missingindex,alpha)
%% initialize

maxIter=100;
m=numanchor;

numview=length(X);
numsample=size(Tlable,1);


%%initialize Z
[A,np]=constructA(X,index);
[B,np0]=constructB(X,missingindex);

Z=cell(numview,1);
for i=1:numview
    Z{i}=zeros(m,np(i));
    if m<=np(i)
        Z{i}(:,1:m) = eye(m);
    else
        Z{i}(1:np(i),1:np(i)) = eye(np(i));
    end

end

%%initialize C

l=k;
C=zeros(l,m);
C(:,1:k)=eye(k);


%%initialize W
d=zeros(1,numview);
W=cell(numview,1);
G=cell(numview,1);
for i = 1:numview
    d(i) = size(X{i},1); 
    W{i} = zeros(d(i),l);
    G{i} = zeros(d(i),l);
end


%%initialize tao
tao = 1e-4; max_tao = 10e12; pho_tao = 1.1;


%%initialize U
U=zeros(m,numsample);

sx=[m,numsample,numview];
%%initialize tensor_J;
J=zeros(1,m*numview*numsample);
tensor_J=reshape(J,[m,numsample,numview]);

%%initialize tensor_Y;
Y=zeros(1,m*numview*numsample);
tensor_Y=reshape(Y,[m,numsample,numview]);
flag=1;
iter=0;

while flag
    iter=iter+1;
    %%Update W;
    for iw=1:numview
        G{iw}=X{iw}*A{iw}*Z{iw}'*C';
        [Unew,~,Vnew] = svd(G{iw},'econ');
        W{iw} = Unew*Vnew';
    end

    %%Update C
    H=0;
    for ic=1:numview
        Hp=W{ic}'*X{ic}*A{ic}*Z{ic}';
        H=H+Hp;
    end
    [Unew2,~,Vnew2] = svd(H,'econ');
    C=Unew2*Vnew2';
    
    %%Update Z

    M=0;
    Yv=0;
    beta=zeros(1,numview);
    for iz=1:numview
        beta(iz)=1/(2*norm(Z{iz}-U*A{iz},'fro')+eps);
        J=tensor_J(:,:,iz);
        M=M+J;
        Y=tensor_Y(:,:,iz);
        Yv=Yv+Y;
        Q=(alpha*C'*W{iz}'*X{iz}*A{iz}+beta(iz)*U*A{iz}+0.5*tao*J*A{iz}-0.5*Y*A{iz})/(alpha+beta(iz)+0.5*tao);
        for izz=1:np(iz)
            ut = Q(:,izz);
            Z{iz}(:,izz) = EProjSimplex_new(ut');
        end
    end

    %%Update U
    
    sumU=0;
    
    M=M/numview;
    Yv=Yv/numview;

    for iu=1:numview
        
        %Update U1p
        Q2=(numview*beta(iu)*Z{iu}+0.5*tao*M*A{iu}-0.5*Yv*A{iu})/(0.5*tao+numview*beta(iu));
        for iiu=1:np
            ut=Q2(:,iiu);
            U1p(:,iiu) = EProjSimplex_new(ut');
        end
        
        %Update U2p 
        Q3=M*B{iu}-1/tao*Yv*B{iu};
        for iiu=1:np0
            ut=Q3(:,iiu);
            U2p(:,iiu) = EProjSimplex_new(ut');
        end
        
        U=U1p*A{iu}'+U2p*B{iu}';
        sumU=sumU+U1p*A{iu}'+U2p*B{iu}';
        
    end
    U=sumU/numview;

    %%Update tensor_Z
    tensor_Z=zeros(sx);
    ZpU=cell(1,numview);
    for ii=1:numview
        ZpU{ii}=(Z{ii}-U*A{ii})*A{ii}'+U;
        tensor_Z(:,:,ii)=ZpU{ii};
    end
   
    
    z=tensor_Z(:);
    
    %% Update tensor_J
    
    y=tensor_Y(:);
    
    [j, objv] = wshrinkObj(z + 1/tao*y,1/tao,sx,0,1);
    tensor_J = reshape(j, sx);

    %%Update tensor_Y
    tensor_Y=tensor_Y+tao*(tensor_Z-tensor_J);

    %%Update tao
    tao = min(tao*pho_tao, max_tao);
   
    term1=0;
    term2=0;
    for i=1:numview
        term1=term1+alpha*norm(X{i}*A{i}-W{i}*C*Z{i},"fro")^2;
        term2=term2+beta(i)*norm(Z{i}-U*A{i},"fro")^2;
    end

    obj(iter)=term1+term2;
    
    if(iter>1)&&(iter>maxIter||abs(obj(iter-1)-obj(iter))<1e-5)
         [UU,~,V]=svd(U','econ');
         UU= UU(:,1:k);
        flag=0;
    end
    
end

